﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WheelProgram.Classes;

namespace WheelProgram.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddEditOrder.xaml
    /// </summary>
    public partial class AddEditOrder : Page
    {
        private Orders _currentOrders = new Orders();
        public AddEditOrder(Orders selectedOrders)
        {
            InitializeComponent();
            if (selectedOrders != null)
                _currentOrders = selectedOrders;
            DataContext = _currentOrders;
            CmbProduct.ItemsSource = WheelBaseEntities.GetContext().Product.ToList();
            CmbProduct.SelectedValuePath = "id_product";
            CmbProduct.DisplayMemberPath = "NameProduct";
            CmbStatus.ItemsSource = WheelBaseEntities.GetContext().Status.ToList();
            CmbStatus.SelectedValuePath = "id_status";
            CmbStatus.DisplayMemberPath = "NameStatus";
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder(); //объект для сообщения об ошибке

            //проверка полей объекта

            //if (string.IsNullOrWhiteSpace(_currentOrders.))
            //    error.AppendLine("Укажите название");

            //if (string.IsNullOrWhiteSpace(_currentProduct.Note))
            //    error.AppendLine("Укажите описание товара");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            //если пользователь новый
            if (_currentOrders.id_order == 0)
                WheelBaseEntities.GetContext().Orders.Add(_currentOrders); //добавить в контекст
            try
            {
                WheelBaseEntities.GetContext().SaveChanges(); // сохраняет все изменения
                MessageBox.Show("Новый заказ добавлен");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString()); //сообщение об ошибке
            }
        }
    }
}
