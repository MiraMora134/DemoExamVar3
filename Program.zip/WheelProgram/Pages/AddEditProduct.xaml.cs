﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WheelProgram.Classes;

namespace WheelProgram.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddEditProduct.xaml
    /// </summary>
    public partial class AddEditProduct : Page
    {
        private Product _currentProduct = new Product();
        public AddEditProduct(Product selectedProduct)
        {
            InitializeComponent();
            if (selectedProduct != null)
                _currentProduct = selectedProduct;

            DataContext = _currentProduct;
            CmbManufacturer.ItemsSource = WheelBaseEntities.GetContext().Manufacturers.ToList();
            CmbManufacturer.SelectedValuePath = "id_manufacturer";
            CmbManufacturer.DisplayMemberPath = "NameManufacturer";
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder(); //объект для сообщения об ошибке

            //проверка полей объекта
            if (string.IsNullOrWhiteSpace(_currentProduct.NameProduct))
                error.AppendLine("Укажите название");
            //if (string.IsNullOrWhiteSpace(_currentProduct.Note))
            //    error.AppendLine("Укажите описание товара");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            //если пользователь новый
            if (_currentProduct.id_product == 0)
                WheelBaseEntities.GetContext().Product.Add(_currentProduct); //добавить в контекст
            try
            {
                WheelBaseEntities.GetContext().SaveChanges(); // сохраняет все изменения
                MessageBox.Show("Новый товар добавлен");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString()); //сообщение об ошибке
            }
        }
    }
}
